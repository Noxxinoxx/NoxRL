using Microsoft.AspNetCore.SignalR;
namespace signalRChat.Hubs {
    public class API : Hub {
        public async Task SendDataset(string statusCode) {
            var file = File.ReadAllText("/home/nox/Desktop/NoxRL/signalRChat/dataset.json");
            Console.WriteLine(file);
            await Clients.Caller.SendAsync("GotData", file);
        }


        public async Task CashOutPart(string data) {
            File.WriteAllText("/home/nox/Desktop/NoxRL/signalRChat/dataset.json", "");
            
            File.WriteAllText("/home/nox/Desktop/NoxRL/signalRChat/dataset.json", data);
            
            await Clients.Caller.SendAsync("Conf");
        }

        public async Task CashInPart(string data) {
            File.WriteAllText("/home/nox/Desktop/NoxRL/signalRChat/dataset.json", "");
            
            File.WriteAllText("/home/nox/Desktop/NoxRL/signalRChat/dataset.json", data);
            
            await Clients.Caller.SendAsync("Conf");
        }
    }
}