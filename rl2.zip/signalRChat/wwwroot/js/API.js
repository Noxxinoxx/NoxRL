"use strict";


var connection = new signalR.HubConnectionBuilder().withUrl("/APIdataset").build();

var input = document.getElementById("input")


connection.start().then(function() {
    console.log("SignalR got a connection to the server!")
    GetData()
}).catch(function() {
    return console.error(err.toString())
})


function GetData() {
    connection.invoke("SendDataset", "data").catch(function (err) {
        return console.error(err.toString());
    });
    
}

async function Logic(data) {
    //console.log(data)
    document.getElementById("DatasetJSON").style.marginTop = "100px"
    var name = []
    var data = JSON.parse(data)
    for(var i = 0; i < data.length; i++) {
        
        name.push(data[i].Model)

    }


    input.addEventListener("input", () => {
        document.getElementById("DatasetJSON").innerHTML = ""
        //console.log(input.value)
        
        for(i = 0; i < data.length; i++) {
            var g = data[i].Model.toUpperCase()
            if(input.value.length == 0) {
                document.getElementById("DatasetJSON").innerHTML = ""
            }else if(g.includes(input.value.toUpperCase()) == true) {
                document.getElementById("DatasetJSON").insertAdjacentHTML("afterbegin",
                    `
                    <br>
                    <table id="tabledataa">
                        <tbody id="tableData" style="width: 75px">
                            <tr style="background-color: #dddddd;">
                                <th>Model</th>
                                <th>Manufacture</th>
                                <th>ID</th>
                            </tr>

                            <tr>
                                <th>`+ data[i].Model +`</th>
                                <th>`+ data[i].Manufacture +`</th>
                                <th>`+ data[i].ID +`</th>
                            </tr>

                            <tr style="background-color: #dddddd">
                                <th>Name</th>
                                <th>AssetTag</th>
                                <th>Count</th>
                                <th>Location</th>
                            </tr>
                        </tbody>
                        
                        
                    </table>
                    `
                
                
                )
                for(var ii = 0; ii < data[i].type.length; ii++) {
                    var Name = data[i].type[ii].Name
                    var Count = data[i].type[ii].Count
                    var Location = data[i].type[ii].Location
                    var AssetTag = data[i].type[ii].AssetTag
                    document.getElementById("tableData").insertAdjacentHTML("beforeend", `
                    <tr>
                        <th>`+ data[i].type[ii].Name +`</th>
                        <th>`+ data[i].type[ii].AssetTag +`</th>
                        <th>`+ data[i].type[ii].Count +`</th>
                        <th>`+ data[i].type[ii].Location +`</th>
                        <th style="width: 10%; height: 100%; background-color: red; " id="deleteButton` + AssetTag + `"> Cash out! </th>
                        <th style="width: 10%; height: 100%; background-color: green; " id="addButton` + AssetTag + `"> Cash in! </th>
                        
                        </tr>    
                    `)
                    
                    DeleteButton("deleteButton" + AssetTag, data, i, ii)
                    addButton("addButton" + AssetTag,data, i, ii)
                }
                
            }
        }

    })




    console.log(data)
}

function DeleteButton(name, data, i, ii) {
    var deleteButton = document.getElementById(name)


    deleteButton.addEventListener("mouseover", () => {
        deleteButton.style.background = "darkred"
    })
    deleteButton.addEventListener("mouseleave", () => {
        deleteButton.style.background = "red"
    })
    if(data[i].type[ii].Count == 0) {
        deleteButton.addEventListener("click", () => {
        
            alert("allready 0 cant delete")
        })
    }else {
        deleteButton.addEventListener("click", () => {
        
            data[i].type[ii].Count = data[i].type[ii].Count - 1
            connection.invoke("CashOutPart", JSON.stringify(data)).catch(function(err) {
                console.error(err.toString())
                alert("server is down fix or restart the server and try again!")
            })

        })
    }

    


}


function addButton(name, data, i, ii) {
    var addButton = document.getElementById(name)

    addButton.addEventListener("mouseover", () => {
        addButton.style.background = "darkgreen"
    })

    addButton.addEventListener("mouseleave", () => {
        addButton.style.background = "green"
    })

    addButton.addEventListener("click", () => {
        data[i].type[ii].Count = data[i].type[ii].Count + 1
        connection.invoke("CashInPart", JSON.stringify(data)).catch(function(err) {
            console.error(err)
            alert("server is down fix or restart the server and try again!")
        })
    })

}


connection.on("Conf", (data) => {
    location.reload()
})

connection.on("GotData", async (data) => {
    console.log("got data")
    await Logic(data)
})
