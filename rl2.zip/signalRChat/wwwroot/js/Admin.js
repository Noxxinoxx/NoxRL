"use strict"


var connection = new signalR.HubConnectionBuilder().withUrl("/ADMINURL").build();


connection.start().then(function() {
    console.log("Connected!")
    GetData()
}).catch(err => {
    console.error(err.toString())
})




connection.on("AdminData", (data) => {
    console.log(data)
    loadBackups(data)
})

connection.on("Backups", (data) => {
    console.log(data)
})


function GetData() {
    connection.invoke("SendData", "getData").catch(err => {
        console.error(err.toString())
    })

    

}


function loadBackups(data) {
    
}