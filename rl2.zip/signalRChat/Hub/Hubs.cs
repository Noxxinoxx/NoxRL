using Microsoft.AspNetCore.SignalR;
namespace signalRChat.Hubs {
    public class API : Hub {

        public string databaseurl = "/home/nox/Desktop/NoxRL/signalRChat/dataset.json";
        public string backupurl = "/home/nox/Desktop/NoxRL/signalRChat/Backups/";
        
        
        public async Task SendDataset(string statusCode) {
            var file = File.ReadAllText(databaseurl);
            
            await Clients.Caller.SendAsync("GotData", file);
        }


        public async Task CashOutPart(string data) {
            Backup();
            File.WriteAllText(databaseurl, "");
            
            File.WriteAllText(databaseurl, data);
            
            await Clients.All.SendAsync("Conf");
        }

        public async Task CashInPart(string data) {
            Backup();
            File.WriteAllText(databaseurl, "");
            
            File.WriteAllText(databaseurl, data);
            
            await Clients.All.SendAsync("Conf");
        }

        public void Backup() {
            DateTime now = DateTime.Now;

            var time = now.ToString().Replace("/", "-");
            time = time.Replace(" ", "_");
        }

    }
}