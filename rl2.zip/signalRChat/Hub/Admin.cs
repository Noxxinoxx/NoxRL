using Microsoft.AspNetCore.SignalR; 
using signalRChat.Hubs;
namespace signalRChat.Hubs {
    public class Admin : Hub {

        public string backupurl = "/home/nox/Desktop/NoxRL/signalRChat/Backups/";
        
        
        public async Task SendData(string data){

            var files = Directory.GetFiles(backupurl);


            await Clients.Caller.SendAsync("AdminData", files);
        }
    }
}