using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace signalRChat.Pages;

public class APIModal : PageModel
{
    private readonly ILogger<APIModal> _logger;

    public APIModal(ILogger<APIModal> logger)
    {
        _logger = logger;
    }

    public void OnGet()
    {

    }
}
