
const { exec } = require("child_process")
//const { FontFamilyName, Text, FontFamily, Spacing, Barcode, BarcodeType, BarcodeTypeName , Label,PrintDensity, PrintDensityName} = require("jszpl")
const fs = require("fs")
var { Label, Alignment, LabelConfig } = require('zpl-label-generator');

// 6dpmm = 152dpi
// 8dpmm = 203dpi
// 12dpmm = 300dpi
// 24dpmm = 600dpi
LabelConfig = {
    dpmm: 8,
    dpi: 203,
    widthMM: 380,
    heightMM: 250,
    defaultLineSpacing: 1,
    defaultPointSize: 6,
    defaultFont: '0',
    marginsMM: {
        top: 1,
        right: 1,
        bottom: 1,
        left: 35,
    },
};

var label = new Label(LabelConfig);

const sampleText = "test"


label.addText('RL - 10', 10);
label.addSpacingMm(3)
label.addBarcode("fdf", 150, 150, 2)

var zpl = label.generateZPL();
console.log(label.generateZPL())
fs.writeFileSync(__dirname + "/label.zpl", "")
fs.writeFileSync(__dirname + "/label.zpl", zpl)


exec("lpr -P Zebra_Technologies_ZTC_GK420t -o raw label.zpl")
