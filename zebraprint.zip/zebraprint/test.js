var fs = require("fs")
const { exec } = require("child_process")








var g = process.argv[2] + " " + process.argv[3] + " " + process.argv[4]

console.log(g)
fs.writeFileSync(__dirname + "/label.zpl", "")
fs.writeFileSync(__dirname + "/label.zpl", `
        ^XA
        ^CFd0,10,18
        ^PR12
        ^LRY
        ^MD30
        ^PW400
        ^LL200
        ^PON
        ^FO110,109^BY1^B3N,N,69N,N^FD` + g + `^FS^FO121,79^FD`+ g + `^FS^PQ1
        ^XZ



`)


exec("lpr -P Zebra_Technologies_ZTC_GK420t -o raw label.zpl")
