var http = require("http")
var express = require("express")
var app = express()
var server = http.createServer(app)
var fs = require("fs")
const bodyParser = require('body-parser'); 

app.use(bodyParser.json()); 
app.get("/data", (req, res) => {
    res.sendFile(__dirname + "/index.html")
})

app.get("/", (req, res ) => {
    //1 = validator = on
    //0 = validator = off
    res.send("1")
})

app.post('/data', function(req, res) {
    var dog = req.body;
    var file = fs.readFileSync(__dirname + "/data.json")
    file = JSON.parse(file)

    file.databasedata.push(dog)
    
    fs.writeFileSync(__dirname + "/data.json", JSON.stringify(file))

});


server.listen(80)